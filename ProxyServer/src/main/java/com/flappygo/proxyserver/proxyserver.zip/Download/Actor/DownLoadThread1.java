package com.flappygo.proxyserver.Download.Actor;

import java.io.File;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CountDownLatch;

public class DownLoadThread1 extends Thread {
    /**
     * 线程ID
     */
    private long threadId;
    /**
     * 下载起始位置
     */
    private long startIndex;
    /**
     * 下载结束位置
     */
    private long endIndex;

    //下载的数据文件
    private File fileDatas;

    private String filePath;

    private int threadCount;

    private long blockSize;

    private String serverUrlPath;

    private CountDownLatch latch;

    public DownLoadThread1(String serverUrlPath,String filePath,int threadCount,long threadId,long blockSize, long startIndex, long endIndex,CountDownLatch latch) {
        this.threadId = threadId;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.filePath = filePath;
        this.threadCount = threadCount;
        this.blockSize = blockSize;
        this.serverUrlPath = serverUrlPath;
        this.latch=latch;
    }


    @Override
    public synchronized void run() {

        try {
            //取得apk文件的写入
            String tempPath = filePath + ".data";
            RandomAccessFile raf = new RandomAccessFile(tempPath, "rwd");
            long offset=0;

            if (threadId > 1 || threadId< threadCount){
                offset=(threadId-1)*blockSize;
            }else if(threadId == threadCount){
                offset=(threadId-1)*blockSize;
            }

            //定位到开始的地方
            raf.seek(offset);
            //url开始连接
            URL url = new URL(serverUrlPath);
            //打开链接
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            //设置RequestProperty
            conn.setRequestProperty("Accept-Encoding", "identity");
            //设置 User-Agent
            conn.setRequestProperty("User-Agent", "NetFox");
            //设置断点续传的开始位置
            conn.setRequestProperty("Range", "bytes=" + startIndex + "-" + endIndex);

            //获取返回值
            int responseCode = conn.getResponseCode();

            //失败抛异常
            if (!(responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_PARTIAL)) {
                throw new Exception("Connection error:" + responseCode + " url:" + url);
            }
            //成功继续执行
            else {
                //获取到input
                InputStream inputStream = conn.getInputStream();
                //缓存大小
                byte[] buffer = new byte[1024];
                //长度
                int readedLen = 0;
                //循环读取
                while ((readedLen = inputStream.read(buffer)) != -1) {
                    //写入数据
                    raf.write(buffer, 0, readedLen);
                }

            }
            latch.countDown();
            // System.out.println("线程" + threadId + "下载完毕");
            //计数值减一
        }
        catch (Exception e) {
            latch.countDown();
            System.out.println("线程内报错");
            e.printStackTrace();
        }

    }
}

