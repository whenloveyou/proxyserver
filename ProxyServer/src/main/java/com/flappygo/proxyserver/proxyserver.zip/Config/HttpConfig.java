package com.flappygo.proxyserver.Config;

public class HttpConfig {

    //网络返回成功
    public static int NET_SUCCESS = 200;

    //网络返回断点续传成功
    public static int NET_SUCCESS_PART = 206;

}
